﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AspNetGridViewExpressionSummary
{
    public class DemoData
    {
        public double Column1 { get; set; }
        public double Column2 { get; set; }
        public double Column3 { get; set; }
        public double Column4 { get; set; }
        public double Column5 { get; set; }
        public double Column6 { get; set; }

        public static DemoData[] Generate()
        {
            int length = 10;

            DemoData[] data = new DemoData[length];

            for (int i = 0; i < length; i++)
            {
                data[i] = new DemoData
                {
                    Column1 = 1 + i,
                    Column2 = 2 + i,
                    Column3 = 3 + i,
                    Column4 = 4 + i,
                    Column5 = 5 + i,
                    Column6 = 6 + i
                };
            }

            return data;
        }
    }
}