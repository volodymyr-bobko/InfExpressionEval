﻿namespace TestExpressionParser
{
    public class AggregateTestDataItem
    {
        public double Field1 { get; set; }
        public double Field2 { get; set; }
        public double Field3 { get; set; }
        public double Field4 { get; set; }
    }
}
