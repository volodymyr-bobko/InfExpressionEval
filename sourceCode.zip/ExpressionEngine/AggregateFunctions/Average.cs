﻿namespace ExpressionEngine.AggregateFunctions
{
    internal class Average: BaseAggregateFunction
    {
        public override string Name
        {
            get { return "AVG"; }
        }

        protected override BaseAggregateState CreateAggregateInstance(string entry)
        {
            return new AverageState(entry);
        }
    }
}
