﻿namespace ExpressionEngine.AggregateFunctions
{
    internal class Min: BaseAggregateFunction
    {
        public override string Name
        {
            get { return "MIN"; }
        }

        protected override BaseAggregateState CreateAggregateInstance(string entry)
        {
            return new MinState(entry);
        }
    }
}
