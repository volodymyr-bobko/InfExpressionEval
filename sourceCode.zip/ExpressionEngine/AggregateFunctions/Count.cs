﻿namespace ExpressionEngine.AggregateFunctions
{
    internal class Count : BaseAggregateFunction
    {
        public override string Name
        {
            get { return "COUNT"; }
        }

        protected override BaseAggregateState CreateAggregateInstance(string entry)
        {
            return new CountState(entry);
        }
    }
}
