﻿namespace ExpressionEngine.AggregateFunctions
{
    internal class Max : BaseAggregateFunction
    {
        public override string Name
        {
            get { return "MAX"; }
        }

        protected override BaseAggregateState CreateAggregateInstance(string entry)
        {
            return new MaxState(entry);
        }
    }
}
