﻿namespace ExpressionEngine.AggregateFunctions
{
    internal class Sum : BaseAggregateFunction
    {
        public override string Name
        {
            get { return "SUM"; }
        }

        protected override BaseAggregateState CreateAggregateInstance(string entry)
        {
            return new SumState(entry);
        }
    }
}
