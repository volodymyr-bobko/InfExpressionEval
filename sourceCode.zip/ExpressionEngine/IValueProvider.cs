﻿namespace ExpressionEngine
{
    /// <summary>
    /// Allows to request concrete values of variables in expression during evaluation
    /// </summary>
    public interface IValueProvider
    {
        /// <summary>
        /// Gets concrete value of specified variable
        /// </summary>
        /// <param name="variableName">variable name</param>
        /// <returns>value for specified variable</returns>
        double GetValue(string variableName);
    }
}
