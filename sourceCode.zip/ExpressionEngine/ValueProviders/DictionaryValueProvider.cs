﻿using System.Collections.Generic;

namespace ExpressionEngine.ValueProviders
{
    public class DictionaryValueProvider : Dictionary<string, double>, IValueProvider 
    {
        public double GetValue(string fieldName)
        {
            return this[fieldName];
        }
    }
}
