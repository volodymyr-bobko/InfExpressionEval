﻿namespace DevExExpressionSummary
{
    partial class ExpressionTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraReports.UI.XRSummary xrSummary1 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary2 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary3 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary4 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary5 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary6 = new DevExpress.XtraReports.UI.XRSummary();
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable2 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow2 = new DevExpress.XtraReports.UI.XRTableRow();
            this.tcColumn1 = new DevExpress.XtraReports.UI.XRTableCell();
            this.tcColumn2 = new DevExpress.XtraReports.UI.XRTableCell();
            this.tcColumn3 = new DevExpress.XtraReports.UI.XRTableCell();
            this.tcColumn4 = new DevExpress.XtraReports.UI.XRTableCell();
            this.tcColumn5 = new DevExpress.XtraReports.UI.XRTableCell();
            this.tcColumn6 = new DevExpress.XtraReports.UI.XRTableCell();
            this.TopMargin = new DevExpress.XtraReports.UI.TopMarginBand();
            this.BottomMargin = new DevExpress.XtraReports.UI.BottomMarginBand();
            this.ReportFooter = new DevExpress.XtraReports.UI.ReportFooterBand();
            this.xlSummary6 = new DevExpress.XtraReports.UI.XRLabel();
            this.xlSummary5 = new DevExpress.XtraReports.UI.XRLabel();
            this.xlSummary4 = new DevExpress.XtraReports.UI.XRLabel();
            this.xlSummary3 = new DevExpress.XtraReports.UI.XRLabel();
            this.xlSummary2 = new DevExpress.XtraReports.UI.XRLabel();
            this.xlSummary1 = new DevExpress.XtraReports.UI.XRLabel();
            this.ReportHeader = new DevExpress.XtraReports.UI.ReportHeaderBand();
            this.xrTable1 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow1 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell4 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell1 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell2 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell5 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell3 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell6 = new DevExpress.XtraReports.UI.XRTableCell();
            this.CaptionStyle = new DevExpress.XtraReports.UI.XRControlStyle();
            this.OddRowStyle = new DevExpress.XtraReports.UI.XRControlStyle();
            this.EvenStyle = new DevExpress.XtraReports.UI.XRControlStyle();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable2});
            this.Detail.HeightF = 25F;
            this.Detail.Name = "Detail";
            this.Detail.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrTable2
            // 
            this.xrTable2.EvenStyleName = "EvenStyle";
            this.xrTable2.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrTable2.Name = "xrTable2";
            this.xrTable2.OddStyleName = "OddRowStyle";
            this.xrTable2.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow2});
            this.xrTable2.SizeF = new System.Drawing.SizeF(700F, 25F);
            // 
            // xrTableRow2
            // 
            this.xrTableRow2.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.tcColumn1,
            this.tcColumn2,
            this.tcColumn3,
            this.tcColumn4,
            this.tcColumn5,
            this.tcColumn6});
            this.xrTableRow2.Name = "xrTableRow2";
            this.xrTableRow2.Weight = 1D;
            // 
            // tcColumn1
            // 
            this.tcColumn1.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.tcColumn1.Name = "tcColumn1";
            this.tcColumn1.StylePriority.UseBorders = false;
            this.tcColumn1.StylePriority.UseTextAlignment = false;
            this.tcColumn1.Text = "Column1";
            this.tcColumn1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.tcColumn1.Weight = 0.5D;
            // 
            // tcColumn2
            // 
            this.tcColumn2.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.tcColumn2.Name = "tcColumn2";
            this.tcColumn2.StylePriority.UseBorders = false;
            this.tcColumn2.StylePriority.UseTextAlignment = false;
            this.tcColumn2.Text = "Column2";
            this.tcColumn2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.tcColumn2.Weight = 0.5D;
            // 
            // tcColumn3
            // 
            this.tcColumn3.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.tcColumn3.Name = "tcColumn3";
            this.tcColumn3.StylePriority.UseBorders = false;
            this.tcColumn3.StylePriority.UseTextAlignment = false;
            this.tcColumn3.Text = "Column3";
            this.tcColumn3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.tcColumn3.Weight = 0.5D;
            // 
            // tcColumn4
            // 
            this.tcColumn4.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.tcColumn4.Name = "tcColumn4";
            this.tcColumn4.StylePriority.UseBorders = false;
            this.tcColumn4.StylePriority.UseTextAlignment = false;
            this.tcColumn4.Text = "Column4";
            this.tcColumn4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.tcColumn4.Weight = 0.5D;
            // 
            // tcColumn5
            // 
            this.tcColumn5.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.tcColumn5.Name = "tcColumn5";
            this.tcColumn5.StylePriority.UseBorders = false;
            this.tcColumn5.StylePriority.UseTextAlignment = false;
            this.tcColumn5.Text = "Column5";
            this.tcColumn5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.tcColumn5.Weight = 0.5D;
            // 
            // tcColumn6
            // 
            this.tcColumn6.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Right) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.tcColumn6.Name = "tcColumn6";
            this.tcColumn6.StylePriority.UseBorders = false;
            this.tcColumn6.StylePriority.UseTextAlignment = false;
            this.tcColumn6.Text = "Column6";
            this.tcColumn6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.tcColumn6.Weight = 0.5D;
            // 
            // TopMargin
            // 
            this.TopMargin.HeightF = 0F;
            this.TopMargin.Name = "TopMargin";
            this.TopMargin.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.TopMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // BottomMargin
            // 
            this.BottomMargin.HeightF = 0F;
            this.BottomMargin.Name = "BottomMargin";
            this.BottomMargin.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.BottomMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // ReportFooter
            // 
            this.ReportFooter.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xlSummary6,
            this.xlSummary5,
            this.xlSummary4,
            this.xlSummary3,
            this.xlSummary2,
            this.xlSummary1});
            this.ReportFooter.HeightF = 212.5417F;
            this.ReportFooter.Name = "ReportFooter";
            this.ReportFooter.StylePriority.UseBackColor = false;
            // 
            // xlSummary6
            // 
            this.xlSummary6.LocationFloat = new DevExpress.Utils.PointFloat(10.00001F, 189.5417F);
            this.xlSummary6.Name = "xlSummary6";
            this.xlSummary6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xlSummary6.SizeF = new System.Drawing.SizeF(681.6666F, 23F);
            xrSummary1.FormatString = "MAX(Column6-1)-2 = {0}";
            xrSummary1.Func = DevExpress.XtraReports.UI.SummaryFunc.Custom;
            xrSummary1.Running = DevExpress.XtraReports.UI.SummaryRunning.Report;
            this.xlSummary6.Summary = xrSummary1;
            // 
            // xlSummary5
            // 
            this.xlSummary5.LocationFloat = new DevExpress.Utils.PointFloat(8.333333F, 154.125F);
            this.xlSummary5.Name = "xlSummary5";
            this.xlSummary5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xlSummary5.SizeF = new System.Drawing.SizeF(681.6667F, 22.99997F);
            xrSummary2.FormatString = "MIN(Column5+1)+2 = {0}";
            xrSummary2.Func = DevExpress.XtraReports.UI.SummaryFunc.Custom;
            xrSummary2.Running = DevExpress.XtraReports.UI.SummaryRunning.Report;
            this.xlSummary5.Summary = xrSummary2;
            // 
            // xlSummary4
            // 
            this.xlSummary4.LocationFloat = new DevExpress.Utils.PointFloat(8.333333F, 113.5F);
            this.xlSummary4.Name = "xlSummary4";
            this.xlSummary4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xlSummary4.SizeF = new System.Drawing.SizeF(681.6667F, 23.00002F);
            xrSummary3.FormatString = "AVG(Column4/Column3) = {0:N2}";
            xrSummary3.Func = DevExpress.XtraReports.UI.SummaryFunc.Custom;
            xrSummary3.Running = DevExpress.XtraReports.UI.SummaryRunning.Report;
            this.xlSummary4.Summary = xrSummary3;
            // 
            // xlSummary3
            // 
            this.xlSummary3.LocationFloat = new DevExpress.Utils.PointFloat(8.333333F, 80.16666F);
            this.xlSummary3.Name = "xlSummary3";
            this.xlSummary3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xlSummary3.SizeF = new System.Drawing.SizeF(681.6667F, 23F);
            xrSummary4.FormatString = "SUM((Column3 + Column2)/2) = {0}";
            xrSummary4.Func = DevExpress.XtraReports.UI.SummaryFunc.Custom;
            xrSummary4.Running = DevExpress.XtraReports.UI.SummaryRunning.Report;
            this.xlSummary3.Summary = xrSummary4;
            // 
            // xlSummary2
            // 
            this.xlSummary2.LocationFloat = new DevExpress.Utils.PointFloat(8.333333F, 45.87498F);
            this.xlSummary2.Name = "xlSummary2";
            this.xlSummary2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xlSummary2.SizeF = new System.Drawing.SizeF(681.6667F, 23F);
            xrSummary5.FormatString = "(SUM(Column3)-SUM(Column2))/COUNT() = {0}";
            xrSummary5.Func = DevExpress.XtraReports.UI.SummaryFunc.Custom;
            xrSummary5.Running = DevExpress.XtraReports.UI.SummaryRunning.Report;
            this.xlSummary2.Summary = xrSummary5;
            // 
            // xlSummary1
            // 
            this.xlSummary1.LocationFloat = new DevExpress.Utils.PointFloat(8.333333F, 10.00001F);
            this.xlSummary1.Name = "xlSummary1";
            this.xlSummary1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xlSummary1.SizeF = new System.Drawing.SizeF(681.6667F, 23F);
            xrSummary6.FormatString = " SUM(Column1) = {0}";
            xrSummary6.Func = DevExpress.XtraReports.UI.SummaryFunc.Custom;
            xrSummary6.Running = DevExpress.XtraReports.UI.SummaryRunning.Report;
            this.xlSummary1.Summary = xrSummary6;
            // 
            // ReportHeader
            // 
            this.ReportHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable1});
            this.ReportHeader.HeightF = 25F;
            this.ReportHeader.Name = "ReportHeader";
            // 
            // xrTable1
            // 
            this.xrTable1.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrTable1.Name = "xrTable1";
            this.xrTable1.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow1});
            this.xrTable1.SizeF = new System.Drawing.SizeF(700F, 25F);
            this.xrTable1.StyleName = "CaptionStyle";
            // 
            // xrTableRow1
            // 
            this.xrTableRow1.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell4,
            this.xrTableCell1,
            this.xrTableCell2,
            this.xrTableCell5,
            this.xrTableCell3,
            this.xrTableCell6});
            this.xrTableRow1.Name = "xrTableRow1";
            this.xrTableRow1.Weight = 1D;
            // 
            // xrTableCell4
            // 
            this.xrTableCell4.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell4.Name = "xrTableCell4";
            this.xrTableCell4.StylePriority.UseBorders = false;
            this.xrTableCell4.StylePriority.UseTextAlignment = false;
            this.xrTableCell4.Text = "Column1";
            this.xrTableCell4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell4.Weight = 0.5D;
            // 
            // xrTableCell1
            // 
            this.xrTableCell1.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell1.Name = "xrTableCell1";
            this.xrTableCell1.StylePriority.UseBorders = false;
            this.xrTableCell1.StylePriority.UseTextAlignment = false;
            this.xrTableCell1.Text = "Column2";
            this.xrTableCell1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell1.Weight = 0.5D;
            // 
            // xrTableCell2
            // 
            this.xrTableCell2.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell2.Name = "xrTableCell2";
            this.xrTableCell2.StylePriority.UseBorders = false;
            this.xrTableCell2.StylePriority.UseTextAlignment = false;
            this.xrTableCell2.Text = "Column3";
            this.xrTableCell2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell2.Weight = 0.5D;
            // 
            // xrTableCell5
            // 
            this.xrTableCell5.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell5.Name = "xrTableCell5";
            this.xrTableCell5.StylePriority.UseBorders = false;
            this.xrTableCell5.StylePriority.UseTextAlignment = false;
            this.xrTableCell5.Text = "Column4";
            this.xrTableCell5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell5.Weight = 0.5D;
            // 
            // xrTableCell3
            // 
            this.xrTableCell3.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell3.Name = "xrTableCell3";
            this.xrTableCell3.StylePriority.UseBorders = false;
            this.xrTableCell3.StylePriority.UseTextAlignment = false;
            this.xrTableCell3.Text = "Column5";
            this.xrTableCell3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell3.Weight = 0.5D;
            // 
            // xrTableCell6
            // 
            this.xrTableCell6.Borders = ((DevExpress.XtraPrinting.BorderSide)((((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Right) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell6.Name = "xrTableCell6";
            this.xrTableCell6.StylePriority.UseBorders = false;
            this.xrTableCell6.StylePriority.UseTextAlignment = false;
            this.xrTableCell6.Text = "Column6";
            this.xrTableCell6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell6.Weight = 0.5D;
            // 
            // CaptionStyle
            // 
            this.CaptionStyle.BackColor = System.Drawing.Color.RosyBrown;
            this.CaptionStyle.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CaptionStyle.Name = "CaptionStyle";
            // 
            // OddRowStyle
            // 
            this.OddRowStyle.BackColor = System.Drawing.Color.IndianRed;
            this.OddRowStyle.Name = "OddRowStyle";
            // 
            // EvenStyle
            // 
            this.EvenStyle.BackColor = System.Drawing.Color.LightCoral;
            this.EvenStyle.Name = "EvenStyle";
            // 
            // ExpressionTest
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.TopMargin,
            this.BottomMargin,
            this.ReportFooter,
            this.ReportHeader});
            this.Margins = new System.Drawing.Printing.Margins(0, 0, 0, 0);
            this.PageWidth = 700;
            this.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            this.StyleSheet.AddRange(new DevExpress.XtraReports.UI.XRControlStyle[] {
            this.CaptionStyle,
            this.OddRowStyle,
            this.EvenStyle});
            this.Version = "11.2";
            ((System.ComponentModel.ISupportInitialize)(this.xrTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.TopMarginBand TopMargin;
        private DevExpress.XtraReports.UI.BottomMarginBand BottomMargin;
        private DevExpress.XtraReports.UI.ReportFooterBand ReportFooter;
        private DevExpress.XtraReports.UI.ReportHeaderBand ReportHeader;
        private DevExpress.XtraReports.UI.XRTable xrTable1;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow1;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell1;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell2;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell3;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell4;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell5;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell6;
        private DevExpress.XtraReports.UI.XRTable xrTable2;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow2;
        private DevExpress.XtraReports.UI.XRTableCell tcColumn1;
        private DevExpress.XtraReports.UI.XRTableCell tcColumn2;
        private DevExpress.XtraReports.UI.XRTableCell tcColumn3;
        private DevExpress.XtraReports.UI.XRTableCell tcColumn4;
        private DevExpress.XtraReports.UI.XRTableCell tcColumn5;
        private DevExpress.XtraReports.UI.XRTableCell tcColumn6;
        private DevExpress.XtraReports.UI.XRControlStyle CaptionStyle;
        private DevExpress.XtraReports.UI.XRControlStyle OddRowStyle;
        private DevExpress.XtraReports.UI.XRControlStyle EvenStyle;
        private DevExpress.XtraReports.UI.XRLabel xlSummary4;
        private DevExpress.XtraReports.UI.XRLabel xlSummary3;
        private DevExpress.XtraReports.UI.XRLabel xlSummary2;
        private DevExpress.XtraReports.UI.XRLabel xlSummary1;
        private DevExpress.XtraReports.UI.XRLabel xlSummary5;
        private DevExpress.XtraReports.UI.XRLabel xlSummary6;
    }
}
