﻿using DevExpress.XtraReports.UI;
using XtraReportsExpressionSummary;

namespace DevExExpressionSummary
{
    public partial class ExpressionTest : XtraReport
    {
        public ExpressionTest()
        {
            InitializeComponent();

            tcColumn1.DataBindings.Add("Text", null, "Column1");
            tcColumn2.DataBindings.Add("Text", null, "Column2");
            tcColumn3.DataBindings.Add("Text", null, "Column3");
            tcColumn4.DataBindings.Add("Text", null, "Column4");
            tcColumn5.DataBindings.Add("Text", null, "Column5");
            tcColumn6.DataBindings.Add("Text", null, "Column6");

            DataSource = DemoData.Generate();

            xlSummary1.DataBindings.Add("Text", null, "Column1");
            xlSummary1.SetExpression("SUM(Column1)");

            xlSummary2.DataBindings.Add("Text", null, "Column2");
            xlSummary2.SetExpression("(SUM(Column3)-SUM(Column2))/COUNT()");

            xlSummary3.DataBindings.Add("Text", null, "Column3");
            xlSummary3.SetExpression("SUM((Column3 + Column2)/2)");

            xlSummary4.DataBindings.Add("Text", null, "Column4");
            xlSummary4.SetExpression("AVG(Column4/Column3)");

            xlSummary5.DataBindings.Add("Text", null, "Column5");
            xlSummary5.SetExpression("MIN(Column5+1)+2");

            xlSummary6.DataBindings.Add("Text", null, "Column6");
            xlSummary6.SetExpression("MAX(Column6-1)-2");
        }

    }
}
