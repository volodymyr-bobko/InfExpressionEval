﻿using System;
using System.Web.UI;
using ExpressionEngine;
using System.Drawing;
using System.Web.Services;
using ExpressionEngine.ValueProviders;

namespace DevExExpressionSummary
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            ReportViewer1.Report = new ExpressionTest();
            ReportViewer1.Report.DataSource = DemoData.Generate();
            
            if(!IsPostBack)
                ReportViewer1.DataBind();
        }

        [WebMethod]
        public static string EvaluateStatic(string expression, VariableDTO[] vars)
        {
            DictionaryValueProvider valProvider = new DictionaryValueProvider();
            foreach (VariableDTO v in vars)
                valProvider[v.Name] = v.Value;
            
            return new ExpressionEveluator(expression).Evaluate(valProvider).ToString();
        }
    }
}